import { expect, test } from '@playwright/test';

test('Trace exercise: intentional assertion failure', async ({ page }) => {
  await page.goto('/');
  await page.getByTestId('username').fill('standard_user');
  await page.getByTestId('password').fill('secret_sauce');
  await page.getByRole('button', { name: 'Login', exact: true }).click();
  await expect(page).toHaveURL('/inventory.html');
  await expect(page.getByText('Products', { exact: true })).toHaveText('Inventory', { timeout: 2000 });
});